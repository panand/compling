from collections import Counter
import nltk.stem
import copy
import os

lookup_dict = dict()
pos_dict = dict()
mpqa_pos_set = set(['adverb','verb','adj','noun','anypos'])
not_found_pos = Counter()

def lookup(word, pos):
    if '-' not in word and not word.isalpha():
        return None
    word = word.lower()
    pos = convert_pos(pos)
    
    for entry_pos in [pos, 'anypos']:
        if (word, entry_pos) in lookup_dict:
            return lookup_dict[(word, entry_pos)]
    
    return stem_lookup(word, pos)

#TODO - Rewrite to be more efficient/effective (trie?)
stemmer = nltk.stem.PorterStemmer()
def stem_lookup(word, pos):
    word = word.lower()
    pos = convert_pos(pos)
    
    for i in range(0,len(word)-1):
        if i==0:
            stemmed_word = stemmer.stem(word)
            if stemmed_word == word: continue
        else:
            stemmed_word = word[:-i]
        for entry_pos in [pos, 'anypos']:
            if (stemmed_word, entry_pos) in lookup_dict:
                entry = lookup_dict[(stemmed_word, entry_pos)]
                if entry['stemmed']=='y':
                    entry=copy.deepcopy(entry)
                    entry['word']=word
                    entry['stemmed']='n'
                    lookup_dict[(word, entry_pos)]=entry
                    return entry
    return None

def convert_pos(pos):
    if pos in pos_dict:
        return pos_dict[pos]
    not_found_pos[pos]+=1
    return pos

def load(filename):
    for line in open(filename):
        if line=='':continue
        entry = dict()
        for field in line.split():
            try:
                field_name, value = field.split('=')
            except:
                continue
            if field_name.endswith('1'):
                field_name=field_name[:-1]
            entry[field_name]=value
        entry['polarity']=entry['priorpolarity']
        del entry['priorpolarity']
        del entry['len']
        lookup_dict[(entry['word'], entry['pos'])]=entry

def setup_pos_conversion():
    # these lists contain the tags from the Brown Corpus Tag-set associated with the POS used in the subjectivity corpus - not sure where this was gathered or how it was constructed  
    adverbs = ["FW-RB", "FW-RB+CC", "RB", "RB$", "RB+BEZ", "RB+CS", "RBR", "RBR+CS", "RBT", "RN", "RP", "RP+IN", "WRB", "WRB+BER", "WRB+BEZ", "WRB+DO", "WRB+DOD", "WRB+DOD*", "WRB+DOZ", "WRB+IN", "WRB+MD"]
    verbs = ["HV","HV*","HV+TO","HVD","HVD*","HVG","HVN","HVZ","HVZ*","MD", "MD+HV","VB","VB+AT","VB+IN","VB+JJ","VB+PPO","VB+RP","VB+TO","VB+VB","VBD","VBG","VBG+TO","VBN","VBN+TO","VBZ", "VBP"]
    adjectives = ["JJ", "JJ$", "JJ+JJ", "JJR", "JJR+CS", "JJS", "JJT","FW-JJ","FW-JJR","FW-JJT"]
    nouns = ["NNP", "NNPS", "NN","NN$","NN+BEZ","NN+HVD","NN+HVZ","NN+IN","NN+MD","NN+NN","NNS","NNS$","NNS+MD","NP","NP$","NP+BEZ","NP+HVZ","NP+MD","NPS","NPS$","NR","NR$","NR+MD","NRS","FW-AT+NN","FW-AT+NP","FW-IN+NN","FW-IN+NP"]
    
    for mpqa_tag, brown_tag_list in [('adverb',adverbs),('verb',verbs),('adj', adjectives),('noun',nouns)]:
        pos_dict[mpqa_tag]=mpqa_tag
        for brown_tag in brown_tag_list:
            pos_dict[brown_tag]=mpqa_tag

try:
    setup_pos_conversion()
    load(os.path.abspath(os.path.join(os.path.dirname(__file__),'subjclueslen1-HLTEMNLP05.tff')))
except:
    print 'failed to load mpqa dictionary'
    raise
