from mpqa import * 
