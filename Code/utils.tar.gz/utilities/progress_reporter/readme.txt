Used to report progress
