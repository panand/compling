#The idea here is that individual modules can add jar files or directories to
# the appropriate list and then they all get loaded when jpype is started,
# this way we only need one jvm.

#!!Try not to call setup() until you actually need it!!
# doing otherwise may result in jars needed by other modules not being loaded!!

#e.g.      jar_files.append('.../weka-3-7-3/weka.jar')
#or..      ext_dirs.append(os.environ["STANFORD_PARSER_HOME"])
#Call setup() when ready to use
#See weka_interface.py or stanford_nlp.py for examples

import os
import sys

import jpype

jar_files = list()
ext_dirs = list()

interface = None
def setup(mem=None):
    global interface, jar_files, ext_dirs
    if interface == None:
        interface=JpypeInterface(jar_files, ext_dirs, mem=None)        

class JpypeInterface():
    def __init__(self, local_jar_files, local_ext_dirs, mem=None):
        if "JAVA_HOME" not in os.environ:
            sys.stderr.write('You may need to set the "JAVA_HOME" environment variable.\n    On Linux it might look like:  JAVA_HOME=/usr/lib/jvm/java-6-sun/')
        self.startJVM(local_jar_files, local_ext_dirs, mem=mem)
    def startJVM(self, local_jar_files, local_ext_dirs, mem=None):
        if not jpype.isJVMStarted():
            for jar in jar_files:
                if jar is None or not os.path.exists(jar):
                    raise IOError('.jar file not found <'+str(jar)+'>')
            args = list()
            args.append( "-Djava.class.path="+(':'.join(local_jar_files)))
            args.append( "-Djava.ext.dirs="+(':'.join(local_ext_dirs)))
            if mem != None:
               args.append("-Xms%s" % mem)
            jpype.startJVM( jpype.getDefaultJVMPath(),
                           "-ea",
                           *args)
    def shutdownJVM(self):
        """@note: Try to call this when finished, esp. if you want to start a second JVM"""
        if jpype.isJVMStarted():
            jpype.shutdownJVM()
