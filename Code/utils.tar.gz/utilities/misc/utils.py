#  -*- coding: utf-8 -*-
import os
import random
from collections import defaultdict

class random_guard:
    def __init__(self, random_seed=None):
        self.random_seed = random_seed
    def __enter__(self):
        if self.random_seed != None:
            self.original_random_state = random.getstate()
            random.seed(self.random_seed)
        return
    def __exit__(self, type, value, traceback):
        if self.random_seed != None:
            random.setstate(self.original_random_state)

def maybe_convert(obj, func = int):
    """@summary: Tries to call func on obj, 
    if that fails it assumes obj is an iterable
     and tries to call maybe_convert on each item in obj, 
    if that fails, it returns obj unaltered
    
    """
    try: return func(obj)
    except: pass
    
    try: return [maybe_convert(elem, func) for elem in obj]
    except: pass
    
    return obj
    
def from_str(obj):
    temp_obj = obj.strip()
    
    if temp_obj.isdigit() or (temp_obj.startswith('-') and temp_obj[1:].isdigit()):
        return int(temp_obj)
    
    try: return float(temp_obj)
    except: pass

    if temp_obj.capitalize() == 'True':
        return True
    if temp_obj.capitalize() == 'False':
        return False
    
    return obj
    
def ascii_only(text, try_to_replace=True, replace_agressive=True):
    #TODO: make more efficient
    if try_to_replace:
        text = standard_unicode_replacements(text, replace_agressive)
    new_text = [char for char in text if ord(char)<128]
    return ''.join(new_text)


_unicode_mapping =dict()
def _get_unicode_mapping():
    #TODO: Not very complete
    if len(_unicode_mapping)!=0: 
        return _unicode_mapping
    _char_mapping = {"'":[u'',u'',u'´',u'ʼ',u'’',u'ʻ',u'`'],
                     '"':[u'',u'',u'“',u'”'],
                     '-':[u'',u'',u'–',u'—'],
                     '...':[u'',u'…'],
                     '<<':[u'«'],
                     '>>':[u'»'],
                     '1/4':[u'¼'],
                     '1/2':[u'½'],
                     '3/4':[u'¾'],
                     '|':[u'¦'],
                     '~':[u'',u'˜']
                     }
    for ascii_version, unicode_set in _char_mapping.items():
        for unicode_char in unicode_set:
            _unicode_mapping[unicode_char]=ascii_version
    return _unicode_mapping

_agressive_unicode_mapping=dict()
def _get_agressive_unicode_mapping():
    if len(_agressive_unicode_mapping)!=0: 
        return _agressive_unicode_mapping
    _agressive_char_mapping = {
            'A':[u'À',u'Á',u'Â',u'Ã',u'Ä',u'Å'],
            'a':[u'à',u'á',u'â',u'ã',u'ä',u'å'],
            'E':[u'È',u'É',u'Ê',u'Ë'],
            'e':[u'è',u'é',u'ê',u'ë'],
            'I':[u'Ì',u'Í',u'Î',u'Ï'],
            'i':[u'ì',u'í',u'î',u'ï'],
            'O':[u'Ò',u'Ó',u'Ô',u'Õ',u'Ö'],
            'o':[u'ò',u'ó',u'ô',u'õ',u'ö'],
            'U':[u'Ù',u'Ú',u'Û',u'Ü'],
            'u':[u'ù',u'ú',u'û',u'ü'],
            'N':[u'Ñ'],
            'n':[u'ñ'],
            'Y':[u'Ý'],
            'y':[u'ý'],
            'B':[u'ß'],
            '?':[u'¿'],
            '!':[u'¡'],
            '+/-':[u'±'],
            '(c)':[u'©'],
            '(r)':[u'®'],
            'AE':[u'Æ'],
            'ae':[u'æ']
            }
    for ascii_version, unicode_set in _agressive_char_mapping.items():
        for unicode_char in unicode_set:
            _agressive_unicode_mapping[unicode_char]=ascii_version
    return _agressive_unicode_mapping

def standard_unicode_replacements(text, agressive=False):
    unicode_mapping = _get_unicode_mapping()
    if agressive:
        unicode_mapping.update(_get_agressive_unicode_mapping())
    modified_text = text
    #TODO: This is stupid, there has got to be a better way to do this!
    for char, replacement in unicode_mapping.items():
        modified_text=modified_text.replace(char, replacement)
#    modified_text=''
#    for char in text:
#        if ord(char)>127:
#            if char in unicode_mapping:
#                char = unicode_mapping[char]
#            if agressive and char in agressive_unicode_mapping:
#                char = agressive_unicode_mapping[char]
#        modified_text+=char
    return modified_text
    
def cross_product(iterableA, iterableB):
    for entryA in iterableA:
        for entryB in iterableB:
            yield (entryA, entryB)

def from_dicts_to_dict(dict_list, key, delete_key=False, mode='strict'):
    """
    @var mode: 'strict' = raise exception if key found twice
               'ignore' = go with the latest
               'update' = update entry !!Note: Update not implemented yet!!
    @note: This is destructive - it does a shallow copy and if you specify delete_key,
     that key will be gone from the list's items too!

    """
    result = dict()
    for entry in dict_list:
        if mode=='strict' and entry[key] in result:
            raise Exception('Key already in dict!')
        result[entry[key]]=entry
        if delete_key:
            del result[entry[key]][key]
    return result

def balance(instances, key, random_seed=None):
    """@summary: Balances a list, dict, or other iterable of dicts based on their key
    @param random_seed: Allows you to specify a random seed. If specified balance() will preserve and restore random's state.
    
    """
    if len(instances)<=2: return instances #no balancing possible
    with random_guard(random_seed):
        binned = bin_items(instances, key)
        min_size = min(len(values) for values in binned.values())
        new_instances = list()
        for instances_of_category in binned.values():
            new_instances.extend(random.sample(instances_of_category,min_size))
    
        random.shuffle(new_instances)
        if hasattr(instances, 'items'):
            return dict(new_instances)
        else:
            return new_instances

def bin_items(instances, key):
    """@summary: Bins a list, dict, or other iterable of dicts according to their key
    @note: used by balance()
    
    """
    binned = defaultdict(list)
    if hasattr(instances, 'items'):
        for instance_key, instance in instances.items():
            binned[instance[key]].append((instance_key, instance))
    else:
        for instance in instances:
            binned[instance[key]].append(instance)
    return binned

def resample(desired_distribution, original, stopping_point = None):
    """@param desired_distribution: A dict of category->relative counts, fractions, percentages, etc. 
    @param original: A dict of category->list of items in that category
    @note: The function continues until it tries to draw from an empty category.
    @param stopping_point: The number of items to select. 
    (e.g. sample 3000 items using the original distribution). 
    If None, the program continues until it tries to draw from an empty category.
    @note: Feel free to improve. This works and meets my needs but could clearly be improved
    (look it up in knuth). Worst case for finding r's category should not be linear as it is now.
    
    """
    desired_total = sum(desired_distribution.values())
    
    for sample_list in original.values():
        random.shuffle(sample_list)
    
    done = False #could stand to remove this flag...
    resampled_list = list()
    while not done and (stopping_point==None or len(resampled_list)<stopping_point):
        r = random.random()*desired_total
        for category, freq in desired_distribution.items():
            if r < freq:
                if len(original[category]) == 0:
                    done = True
                    break
                resampled_list.append(original[category].pop())
                break
            else:
                r-=  freq
    return resampled_list

def build_folds(data, n=10, random_seed=None, priority='label ratio'): 
    """@var data: key->true_label
    @return: key->fold_number
    
    """
    #TODO: Think about best form for input
    #Likely to wind up with:
    #
    #
    #aab
    #aab
    #ab
    #a
    folds = dict()
    with random_guard(random_seed):
        binned = defaultdict(list)
        for key, label in data.items():
            binned[label].append(key)
        
        for bin_group in binned.values():
            random.shuffle(bin_group)
        
        if priority=='label ratio':
            for bin_group in binned.values():
                current_fold = 0
                for key in bin_group:
                    folds[key]=current_fold
                    current_fold = (current_fold+1)%n
        else:
            pass #TODO: fold balance, error if other
    return folds
    
def build_folds_with_groups(data, groups, n=10, random_seed=None, priority='label ratio'): 
    #TODO: Implement...
    return None


class Walker(object):
    """ 
    os.path.walk is confusing to me and I want to make a class like this, so here it is.
    I could probably use a simple reduce(lambda x, y: x.extend(y), [bla for bla bla bla])
    but this is Python, not Scheme. We do it he Pythonic way. With a generator thing. 
    
    It has since come to my attention that os.path.walk is deprecated and that we have a new
    easy-to-use os.walk. Whatever. It sucks, too. 
    """
    def __init__(self, somedir, countdirs=False):
        self.index = 0
        self.dirstack = [somedir]
        self.filelist = []
        self.countdirs = countdirs
        self.currdir = '.'

    def __getitem__(self, index):
        """ I'm trying this generator thing since we have a lot of files and it seems worthwhile to do. """
        while 1:
            try: 
                myfile = self.filelist[self.index]
                self.index += 1     # I miss ++ and -- :(
            except IndexError: 
                self.currdir = self.dirstack.pop()
#                self.filelist = [os.path.abspath(a) for a in os.listdir(self.currdir)]
                # Abspath fails. Do it manually. 
                self.filelist = os.listdir(self.currdir)
                self.index = 0
                continue

            file_with_path = os.path.join(self.currdir, myfile)
            if os.path.isdir(file_with_path): 
                self.dirstack.append(file_with_path)
                if self.countdirs:
                    return file_with_path
                else:
                    continue
            return file_with_path
            

