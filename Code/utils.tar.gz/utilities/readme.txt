This repository is for useful tools and utilities created or heavily modified and maintained by us. 

My general rule is if we wrote or expect to modify and maintain it, use "utilities" otherwise use "utilities_external".
