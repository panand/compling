import re

#borrowed from nltk w/ modifications
clean_html_regexes = [(re.compile(r"(?is)<(script|style).*?>.*?(</\1>)"), ""),
                     (re.compile(r"(?s)<!--(.*?)-->[\n]?", re.DOTALL), ""),
                     (re.compile(r'(?i)<(b|h)r */? *>'), '\n'),
                     (re.compile(r'(?s)<.*?>'), '')]
def clean_html(text):
    for regex, sub in clean_html_regexes:
        text = regex.sub(sub, text)
    text = replace_html_escapes(text)
    text = text.replace('  ',' ').replace('  ',' ')
    return text

#see: http://www.theukwebdesigncompany.com/articles/entity-escape-characters.php
#and: http://www.fileformat.info/info/unicode/char/201d/index.htm
#  ('&amp;','&') purposely left out - replace on own
html_escapes = [('&nbsp;',' '),
                ('&quot;','"'),
                ('&lt;','<'),
                ('&gt;','>')]
html_escapes_regexes = [(re.compile(r'&(l|r)dquo;', re.IGNORECASE), '"'),
                        (re.compile(r'&(l|r)squo;', re.IGNORECASE), "'"),
                        (re.compile(r'&acute;', re.IGNORECASE), "'")]
lossy_html_escape_regexes = [(re.compile(r'&(A|E|I|O|U|a|e|i|o|u|N|n|Y|y)(grave|acute|circ|tilde|uml|ring);'), r'\1')]

def replace_html_escapes(text, replace_amp = False, use_lossy_escapes = True):
    for original, sub in html_escapes:
        text = text.replace(original, sub)
    for regex, sub in html_escapes_regexes:
        text = regex.sub(sub, text)
    if use_lossy_escapes:
        for regex, sub in lossy_html_escape_regexes:
            text = regex.sub(sub, text)
    if replace_amp:
        text = text.replace('&amp;','&')
    return text
