Various tools for reading, writing, and manipulating files.
