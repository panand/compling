import os
import json
import codecs

skip_list = list()   
def fix_json_file(filename, skip_counter, quiet=True, encoding='utf-8'):
    """Basically adds whitespace and sorts"""
    jsonfile = codecs.open(filename, "r",encoding=encoding)
    
    try:
        data = json.load(jsonfile)
        jsonfile.close()
        jsonfile = codecs.open(filename, "w", encoding=encoding)
        json.dump(data, jsonfile, indent = True)
        jsonfile.close()
        if not quiet:
            print "fixed "+filename
        return skip_counter
    except:
        if not quiet:
            print "\n<< skipping "+filename+" >>"
            print "<< skipped "+str(skip_counter)+" files >>\n"
        skip_list.append(filename)
        skip_counter += 1
        file.close()
        return skip_counter
    
def fix_json_files(jsondir, quiet=True):
    skip_counter = 1
    for subdir, dirs, files in os.walk(jsondir):
        for jsonfile in files:
            if jsonfile.endswith(".json"):
                skip_counter = fix_json_file(jsondir+jsonfile, skip_counter, quiet)
    if not quiet:
        print "\n<< skipped "+str(skip_counter-1)+" files >>\n"
        if skip_list:
            print "files skipped: "
            for jsonfile in skip_list:
                print jsonfile  

if( __name__ == '__main__'):
    import sys
    try:
        assert len(sys.argv)==2, 'Too few or too many arguments!'
        assert os.path.isdir(sys.argv[1]), 'Directory: <'+sys.argv[1]+'> not found!'
        fix_json_files(sys.argv[1])
        
    except:
        print '**********\nUsage: python clean_up_json.py folder\n**********' 
        raise
