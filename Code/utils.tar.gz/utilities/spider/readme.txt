Used for spidering (i.e. scraping/downloading) websites
Requires the mechanize python library

usage:
python spider.py dataset output_dir [seed_file]

dataset: the site-specific Spider object (mostly for building whitelists, blacklists, seeds, and login)
output_dir: the directory to save files
seed_file: a file containing urls to scrape - one per line

output is a directory containing all the html files and a json formatted url_mapping file which maps url to filename
