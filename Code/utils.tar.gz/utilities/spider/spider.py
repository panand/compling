import re
import time
import sys, os
from HTMLParser import HTMLParser
import urlparse
from mechanize import Browser
import codecs
import json
from progress_reporter.progress_reporter import ProgressReporter


class Spider:
    #gathered from wikipedia 6/25/2010
    tlds = set(['aero','asia','biz','cat','com','coop','edu','gov','info','int','jobs','mil','mobi','museum','name','net','org','pro','tel','travel','xxx','ac','ad','ae','af','ag','ai','al','am','an','ao','aq','ar','as','at','au','aw','ax','az','ba','bb','bd','be','bf','bg','bh','bi','bj','bm','bn','bo','br','bs','bt','bv','bw','by','bz','ca','cc','cd','cf','cg','ch','ci','ck','cl','cm','cn','co','cr','cu','cv','cx','cy','cz','de','dj','dk','dm','do','dz','ec','ee','eg','er','es','et','eu','fi','fj','fk','fm','fo','fr','ga','gb','gd','ge','gf','gg','gh','gi','gl','gm','gn','gp','gq','gr','gs','gt','gu','gw','gy','hk','hm','hn','hr','ht','hu','id','ie','il','im','in','io','iq','ir','is','it','je','jm','jo','jp','ke','kg','kh','ki','km','kn','kp','kr','kw','ky','kz','la','lb','lc','li','lk','lr','ls','lt','lu','lv','ly','ma','mc','md','me','mg','mh','mk','ml','mm','mn','mo','mp','mq','mr','ms','mt','mu','mv','mw','mx','my','mz','na','nc','ne','nf','ng','ni','nl','no','np','nr','nu','nz','om','pa','pe','pf','pg','ph','pk','pl','pm','pn','pr','ps','pt','pw','py','qa','re','ro','rs','ru','rw','sa','sb','sc','sd','se','sg','sh','si','sj','sk','sl','sm','sn','so','sr','st','su','sv','sy','sz','tc','td','tf','tg','th','tj','tk','tl','tm','tn','to','tp','tr','tt','tv','tw','tz','ua','ug','uk','us','uy','uz','va','vc','ve','vg','vi','vn','vu','wf','ws','ye','yt','za','zm','zw'])
    class SpiderHTMLParser(HTMLParser):
        def __init__(self):
            self.myparser_links = set()
            HTMLParser.__init__(self)
        def handle_starttag(self, tag, attrs):
            if tag == 'a':
                for attr in attrs:
                    if attr[0] == 'href':
                        self.myparser_links.add(attr[1])

    def get_seeds(self):
        #Override Me!
        return ['http://www.example.com','http://www.example.net']
    def construct_whitelists(self):
        #Override Me!
        self.spider_override = set()
        self.save_override = set()
        self.spiderable_regexes = [re.compile(".")]
        self.saveable_regexes = [re.compile(".")]
        self.blacklist = []
        self.blacklist_regexes =[]
        
    def get_save_filename(self, url):
        return str(len(self.saved_pages))+'.html'

    def save_webpage(self, url):
        filename = self.get_save_filename(url)
        webpage_data = self.get_webpage_data(url)
        output_file = codecs.open(self.outputdir+filename,"w",'utf-8')
        output_file.write(webpage_data)
        output_file.close()
        self.saved_pages.append((filename,url))
        if self.verbosity:
            print 'Saved:     <'+url+'>'
    def record_url_filename_mapping(self):
        index_file = codecs.open(self.outputdir+self.url_filename_mapping, 'w','utf-8')
        json.dump(self.saved_pages, index_file, indent = True, encoding = 'utf-8')
        index_file.close()
    def record_error_urls(self, error_urls):
        output_file = codecs.open(self.outputdir+"errors.txt","w",'utf-8')
        for url in error_urls:
            output_file.write(url+'\n')
            print 'Error on: '+url
        output_file.close()
        

    def should_spider(self, current_url):
        if current_url in self.spider_override:
            return True
        for entry in self.blacklist:
            if entry in current_url:
                return False
        for regex in self.blacklist_regexes:
            if regex.search(current_url):
                return False
        for regex in self.spiderable_regexes:
            if regex.search(current_url):
                return True
        return False
    def should_save(self, current_url):
        if current_url in self.save_override:
            return True
        for entry in self.blacklist:
            if entry in current_url:
                return False
        for regex in self.blacklist_regexes:
            if regex.search(current_url):
                return False
        for regex in self.saveable_regexes:
            if regex.search(current_url):
                return True
        return False
    
    def set_output_dir(self, directory):
        self.outputdir = directory
        if not self.outputdir.endswith('/'):
            self.outputdir+='/'
        if not os.path.exists(self.outputdir):
            os.makedirs(self.outputdir)
            

    def __init__(self, output_dir):
        self.htmlparser = Spider.SpiderHTMLParser()
        self.construct_whitelists()
        self.build_browser()
        self.saved_pages = list()
        self.set_output_dir(output_dir)
        self.url_filename_mapping = 'url_filename_mapping.txt'
        self.recent_url = None
        
        self.progress = ProgressReporter(text='Very Rough! Finished ')
        self.verbosity = 1

    def get_links_from(self, url):
        if self.verbosity:
            print 'Spidering: <'+url+'>'

        self.get_webpage_data(url)
        page_links = self.browser.links()
        links = list()

        for link in page_links:#self.htmlparser.myparser_links:
            links.append( self.expand_relative_url(url, link.url) )
        return links

    def get_webpage_data(self, url):
        """@note: caches"""
        if self.recent_url != url:
            webpage = self.browser.open(url)#urllib2.urlopen(url)
            
            #whatever
            headers = webpage.info()
            charset = 'utf-8'
            if "Content-type" in headers:
                content_type = headers["Content-type"]
                charset = content_type[content_type.index('charset=')+8:]
                if ';' in charset:
                    charset = charset[:charset.index(';')]

            self.recent_data = webpage.read().decode(charset)
            self.recent_url = url
        return self.recent_data
    
    def handle_error(self, err, url, error_urls, pending_webpages):
        print str(err)
        if url not in error_urls:
            print 'ERROR!!! on < '+url+' >'
            print 'trying again...'
            error_urls.add(url)
            pending_webpages.append(url)
            self.reload()
        else:
            print 'ERROR!!! on < '+url+' >'
            print 'giving up...'

    def reload(self):
        print 'Resting for 1 second'
        time.sleep(1)
    
    def build_browser(self):
        #override to add cookies
        self.browser = Browser()


    def to_simple_ascii(self, input_string):
        result_str =''
        for char in input_string:
            if ord(char) > 127:
                char = chr(34)
            result_str += char
        return result_str

    def expand_relative_url(self, base_url, relative_url):
        relative_url = self.to_simple_ascii(relative_url)
        if self.urljoin_breaks_on(relative_url): #e.g. on 'www.yahoo.com' with no 'http://'
            return 'http://'+relative_url #whatever
        return urlparse.urljoin(base_url, relative_url)

    def urljoin_breaks_on(self, url): #e.g. on 'www.yahoo.com' with no 'http://'
        base_url = url[0:url.find('/')]
        if '.' not in base_url:
            return False
        tld = base_url[base_url.rfind('.')+1:]
        return (tld in Spider.tlds)


    def spider(self, max_count=None, additional_seeds=None):
        pending_webpages = self.get_seeds()
        if additional_seeds != None:
            pending_webpages.extend(additional_seeds)
        discovered_webpages = set(pending_webpages)
        error_urls = set()
        while pending_webpages and (max_count == None or max_count > len(self.saved_pages)):
            current_url = pending_webpages.pop()
            try:
                if self.should_save(current_url):
                    self.save_webpage(current_url)
                if self.should_spider(current_url):
                    links = self.get_links_from(current_url)
                    for url in links:
                        if url not in discovered_webpages:
                            pending_webpages.append(url)
                            discovered_webpages.add(url)
                error_urls.discard(current_url)
                self.progress.report(current_number=None, total_number=len(discovered_webpages))
            except EOFError:#catch ctrl+D and record results
                break
            except Exception, err:
                self.handle_error(err, current_url, error_urls, pending_webpages)
        self.record_url_filename_mapping()
        if error_urls:
            self.record_error_urls(error_urls)
            


class DebateDotOrg(Spider):
    def get_seeds(self):
        return ['http://www.debate.org/debates/?page=1&order=1&sort=']
    def construct_whitelists(self):
        self.spider_override = set()
        self.save_override = set()
        self.spiderable_regexes = [
            re.compile(r"^http://www\.debate\.org/debates/\?page=\d+&order=1&sort=$"),
            re.compile(r"^http://www\.debate\.org/debates/.+/\d+/$")]
        self.saveable_regexes = [
            re.compile(r"^http://www\.debate\.org/debates/.+/\d+/$")]
        self.blacklist = []
        self.blacklist_regexes =[]

class fourforums(Spider):
    def __init__(self, output_dir):
        Spider.__init__(self, output_dir)
        self.found=set()
        self.structure_file = codecs.open(self.outputdir+'structure.txt','w',encoding='utf-8')
        self.structure_url_re = re.compile(r"^http://www\.4forums\.com/political/[^/]+/\d+-.*\.html(#post\d+)?$")
        
    def get_seeds(self):
        return ['http://www.4forums.com/political/topics/']
        
    def construct_whitelists(self):
        self.spider_override = set()
        self.save_override = set()
        self.spiderable_regexes = [
            re.compile(r"^http://www\.4forums\.com/political/[^/]+/(index\d+\.html)?$"),
            re.compile(r"^http://www\.4forums\.com/political/[^/]+/\d+-.*\.html$")]

        self.saveable_regexes = [
            re.compile(r"^http://www\.4forums\.com/political/[^/]+/\d+-.*-print\.html$"),
            re.compile(r"^http://www\.4forums\.com/political/[^/]+/poll-\d+-.*\.html$")]
        
        self.spiderable_regexes.extend(self.saveable_regexes)
        
        self.blacklist = ['?','.html#links','.html#post','-new-post.html', '-next-thread.html', '-prev-thread.html', '/political/open-forum/','political/polls-forum/', 'political/suggestions/','political/introductions/','#top','#goto_']
        self.blacklist_regexes = [re.compile(r'-post\d+\.html$')]

        robots = [
                "http://www.4forums.com/political/images/",
                "http://www.4forums.com/political/members/",
                "http://www.4forums.com/political/ajax.php",
                "http://www.4forums.com/political/attachment.php",
                "http://www.4forums.com/political/calendar.php",
                "http://www.4forums.com/political/cron.php",
                "http://www.4forums.com/political/editpost.php",
                "http://www.4forums.com/political/global.php",
                "http://www.4forums.com/political/image.php",
                "http://www.4forums.com/political/faq.php",
                "http://www.4forums.com/political/inlinemod.php",
                "http://www.4forums.com/political/joinrequests.php",
                "http://www.4forums.com/political/login.php",
                "http://www.4forums.com/political/member.php",
                "http://www.4forums.com/political/misc.php",
                "http://www.4forums.com/political/moderator.php",
                "http://www.4forums.com/political/newattachment.php",
                "http://www.4forums.com/political/newreply.php",
                "http://www.4forums.com/political/newthread.php",
                "http://www.4forums.com/political/online.php",
                "http://www.4forums.com/political/poll.php",
                "http://www.4forums.com/political/postings.php",
                "http://www.4forums.com/political/printthread.php",
                "http://www.4forums.com/political/private.php",
                "http://www.4forums.com/political/profile.php",
                "http://www.4forums.com/political/register.php",
                "http://www.4forums.com/political/report.php",
                "http://www.4forums.com/political/reputation.php",
                "http://www.4forums.com/political/search.php",
                "http://www.4forums.com/political/sendmessage.php",
                "http://www.4forums.com/political/payments.php",
                "http://www.4forums.com/political/showpost.php",
                "http://www.4forums.com/political/showgroups.php",
                "http://www.4forums.com/political/spiders.php",
                "http://www.4forums.com/political/subscription.php",
                "http://www.4forums.com/political/threadrate.php",
                "http://www.4forums.com/political/usercp.php",
                "http://www.4forums.com/political/usernote.php",
                "http://www.4forums.com/political/admincp/",
                "http://www.4forums.com/political/cgi-bin/",
                "http://www.4forums.com/political/includes/",
                "http://www.4forums.com/political/install/",
                "http://www.4forums.com/political/modcp/",
                "http://www.4forums.com/political/customavatars/",
                "http://www.4forums.com/political/archive/",
                "http://www.4forums.com/political/gallery/misc.php",
                "http://www.4forums.com/political/gallery/ecard.php",
                "http://www.4forums.com/political/phpmemberlist.php"
                ]
        self.blacklist.extend(robots)


    def build_browser(self):
        #[citation needed]
        self.browser = Browser()                         # Create a browser
        self.browser.open("http://www.4forums.com/political/economics-debates/15416-ph-d-economics-one-sentence.html?mode=threaded#post432217")
#        # Open the login page
#        self.browser.open("http://www.4forums.com/political/index.php") 
#
#        self.browser.select_form(nr = 0)                 # Find the login form
#        self.browser['vb_login_username'] = 'fourforumsun'     # Set the form values
#        self.browser['vb_login_password'] = 'qwerty'
#        self.browser.submit()                     # Submit the form
#
#        # Automatic redirect sometimes fails, follow manually when needed
#        if 'Redirecting' in self.browser.title():
#            self.browser.follow_link(text_regex='click here')

    def reload(self):
        print 'Sleeping for 1 minute, reloading browser and trying again'
        time.sleep(60)
        self.build_browser()
    
    def get_links_from(self, url):
        if url in self.spider_override: self.spider_override.remove(url)#just to keep the set small
        if url.endswith('-print.html') or self.structure_url_re.search(url)==None:
            return Spider.get_links_from(self, url)
        else:
            if '.html#post' in url:
                current_post_id = int(url[url.rfind('t')+1:])
                if current_post_id in self.found: 
                    return []
            links = Spider.get_links_from(self, url)
            is_poll = False
            self.structure_file.write('--------\n'+url+'\n\n')
            data = self.get_webpage_data(url)
            for line in data.split('\n'):#sure hope it uses \n...
                striped_line = line.strip()
                if '<!-- end post links -->' in striped_line: break
                if url.endswith('.html') and striped_line.strip().startswith('View Poll Results'): 
                    is_poll=True
                if is_poll:
                    self.structure_file.write('poll markup: '+line+'\n')
                    if striped_line.startswith('<!-- controls above postbits -->'):
                        is_poll = False
                        self.structure_file.write('\n')
                if striped_line.startswith('pu['):
                    self.structure_file.write(line+'\n')
                if striped_line.startswith('writeLink('):
                    self.structure_file.write(line+'\n')
                    post_id = int(striped_line[10:striped_line.find(',')])
                    if post_id not in self.found and '"more", ""' in line:
                        base = url[:-5] if url.endswith('.html') else url[:url.rfind('-')]
                        new_url = base+'-post'+str(post_id)+'.html#post'+str(post_id)
                        links.append(new_url)
                        self.spider_override.add(new_url)
                    else:
                        self.found.add(post_id)
        return links

class carm(Spider):
    def get_seeds(self):
        return ['http://forums.carm.org/vbb/forum.php']

    def construct_whitelists(self):
        self.spider_override = set()
        self.save_override = set()
        self.spiderable_regexes = [
            re.compile(r"^http://forums\.carm\.org/vbb/forumdisplay\.php\?([0-9])*(-[^&?/#]+)+(/page\d+&order=desc)?$"),
            re.compile(r"^http://forums\.carm\.org/vbb/showthread\.php\?([0-9])*(-[^&?/#]+)+(/page\d+&p=\d+)?$"), 
            re.compile(r"^http://forums\.carm\.org/vbb/forum\.php$")]

        self.saveable_regexes = [
            re.compile(r"^http://forums\.carm\.org/vbb/showthread\.php\?([0-9])*(-[^&?/#]+)+(/page\d+&p=\d+)?$")]
            
        self.blacklist = [] #add breadcrumb trail to metadata and filter based on that
        self.blacklist_regexes =[]
            
    def build_browser(self):
        #[citation needed]
        self.browser = Browser()                         # Create a browser

        # Open the login page
        self.browser.open("http://forums.carm.org/vbb/login.php") 

        self.browser.select_form(nr = 0)                 # Find the login form
        self.browser['vb_login_username'] = 'carmun'     # Set the form values
        self.browser['vb_login_password'] = 'qwerty'
        self.browser.submit()                     # Submit the form

        # Automatic redirect sometimes fails, follow manually when needed
        if 'Redirecting' in self.browser.title():
            self.browser.follow_link(text_regex='click here')

    def reload(self):
        print 'Sleeping for 1 minute, reloading browser and trying again'
        time.sleep(60)
        self.build_browser()
        
        


class convinceme(Spider):
    def get_seeds(self):
        return ['http://www.convinceme.net/viewAllTags.php', 'http://www.convinceme.net/opendebate/5/Ninjas-versus-Pirates.html']

    def construct_whitelists(self):
        self.spider_override = set()
        self.save_override = set()
        self.spiderable_regexes = [re.compile(r"http://www.convinceme.net/viewAllTags.php(\?start=\d+)?$"), 
                                   re.compile(r"^http://www\.convinceme\.net/(opendebate|coldebate)/\d+/(.*)\.html$"), 
                                   re.compile(r"^http://www\.convinceme\.net/opentopics\?topic=.*$"), 
                                   re.compile(r"^http://www\.convinceme\.net/open-debates\?cat=\d+$"), 
                                   re.compile(r"http://www\.convinceme\.net/open-debates")]
        self.saveable_regexes = [re.compile(r"^http://www\.convinceme\.net/(opendebate|coldebate)/\d+/(.*)\.html$")]
        self.blacklist = []
        self.blacklist_regexes =[]

class SlateFray(Spider):
    def spider(self, max_count=None, additional_seeds=None):
        pending_webpages = self.get_seeds()
        discovered_webpages = set(pending_webpages)
        while pending_webpages and (max_count == None or max_count > len(self.saved_pages)):
            current_url = pending_webpages.pop()

            if self.should_save(current_url):
                self.save_webpage(current_url)
                if SlateFray.head_page.search(current_url) and current_url+"?View=Threaded" not in discovered_webpages:
                    self.save_webpage(current_url+"?View=Threaded")
                    self.browser.cookies.clear_All()
                    #pending_webpages.append(current_url+"?View=Threaded")
                    discovered_webpages.add(current_url+"?View=Threaded")
            if self.should_spider(current_url):
                links = self.get_links_from(current_url)
                for url in links:
                    if url not in discovered_webpages:
                        pending_webpages.append(url)
                        discovered_webpages.add(url)
        self.record_url_filename_mapping()

    def get_seeds(self):
        return ['http://fray.slate.com/discuss/']

    head_page = re.compile(r"^http://fray\.slate\.com/discuss/forums/thread/\d+\.aspx$")

    def construct_whitelists(self):
        self.spider_override = set()
        self.save_override = set()
        self.spiderable_regexes = [re.compile(r"^http://fray\.slate\.com/discuss/forums/\d+/ShowForum\.aspx$"), 
                                   re.compile(r"^http://fray\.slate\.com/discuss/$"),
                                   re.compile(r"^http://fray\.slate\.com/discuss/tags/\w+(\+\w+)*/default\.aspx$"),
                                   SlateFray.head_page,
                                   re.compile(r"^http://fray\.slate\.com/discuss/forums/\d+/\d+/ShowThread.aspx$")]
        self.saveable_regexes = [SlateFray.head_page,
                                 re.compile(r"^http://fray\.slate\.com/discuss/forums/thread/\d+\.aspx?View=Threaded$"),
                                 re.compile(r"^http://fray\.slate\.com/discuss/forums/\d+/\d+/ShowThread.aspx$")]
        self.blacklist = ['http://fray.slate.com/discuss/forums/1/']
        self.blacklist_regexes =[]

if( __name__ == '__main__'):
    try:
        assert 3 <= len(sys.argv) <=4, 'Too few or too many arguments!'
    
        dataset_name = sys.argv[1]
        output_dir = sys.argv[2]
        seed_file = None
        if len(sys.argv)>=4:
            seed_file = sys.argv[3]
        assert seed_file==None or os.path.isfile(seed_file), 'The seed list file <'+seed_file+'> does not exist!'
        
        assert dataset_name in globals(), 'Couldn\'t find dataset <'+dataset_name+'>!'
        spider = globals()[dataset_name](output_dir)
        assert isinstance(spider, Spider), 'Dataset <'+dataset_name+'> not a Spider Class object!'
    
        seeds = list()
        if seed_file != None:
            for line in open(seed_file):
                seeds.append(line.strip())
    except:
        print '**********\nUsage: python spider.py dataset output_dir [seed_file]\n**********' 
        print 'Also, be sure to check the robots.txt file!\n' 
        raise
    
    spider.spider(additional_seeds=seeds)
