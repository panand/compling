import numpy

def get_cosine_similarity(vector1, vector2):
    """@note: expects the vectors to be iterables over real numbers"""
    magnitude1 = numpy.linalg.norm(vector1)
    magnitude2 = numpy.linalg.norm(vector2)
    if magnitude1 == 0 or magnitude2 == 0:
        return 0.0
    return numpy.dot(vector1, vector2)/float(magnitude1*magnitude2)
