import os, sys
import random
from collections import defaultdict
from file_formatting import csv_wrapper
from misc import utils, jpype_interface

_weka = None  #Don't use this directly! Use get_weka()
def get_weka():
    """Returns the java package: "weka"
    @note: Mostly for internal use, but available if desired
    
    """
    global _weka
    if _weka is None:
        jpype_interface.setup()
        _weka = jpype_interface.jpype.JPackage("weka")
    return _weka

def load_inputs(arff_folder, arffs, classification_feature=None):
    """@var arff_folder: The folder where your arff files are
    @var arffs: A list of arff files to load. The ".arff" extension is optional
    @var classification_feature: The ClassAttribute/Label/Y. If unspecified, the last feature of the last arff in arffs will be used
    @return: Returns a Weka Instances object (instances) and additional data about the instances (meta_data)
    
    """
    instances, possible_instance_keys = _load_arffs(arff_folder, arffs, classification_feature)
    if possible_instance_keys is not None:
        meta_data = defaultdict(dict)
        arff_index=0
        for key in possible_instance_keys:
            meta_data[key]['key']=key
            meta_data[key]['arff_index']=arff_index
            arff_index+=1
    elif os.path.exists(arff_folder+'instances.csv'):
        meta_data = _load_meta_data(arff_folder)
    else:
        meta_data = defaultdict(dict)
        for arff_index in range(instances.numInstances()):
            meta_data[arff_index]['key']=arff_index
            meta_data[arff_index]['arff_index']=arff_index
    return instances, meta_data

def build_model(training_instances, classifier_name, classifier_options=None, attribute_selection=None, attribute_selection_options=None, meta_data=None, training_keys=None, random_seed=None):
    """@var training_instances: A Weka Instances object, if training_keys and meta_data are specified then only those instances will be used
    @var classifier_name: The fully specified name of the classifier you intend to use. e.g. 'weka.classifiers.rules.JRip'
    @var attribute_selection: not yet implemented
    @var random_seed: This will be used if specified and the classifier implements setSeed()
    
    """
    if meta_data is not None and training_keys is not None:
        training_instances = _extract_subset(training_instances, meta_data, training_keys)
    classifier = get_weka().classifiers.AbstractClassifier.forName(classifier_name, classifier_options)
    if random_seed is not None:
        try:
            classifier.setSeed(random_seed)
        except:
            pass
    classifier.buildClassifier(training_instances)
    return classifier

def store_model(model, filename):
    """@var model: A Weka Classifier object"""
    get_weka().core.SerializationHelper.write(filename, model)

def load_model(filename):
    """Loads a previously stored Weka Classifier object"""
    model = get_weka().core.SerializationHelper.read(filename)
    return model

def apply_model(model, testing_instances, meta_data=None, testing_keys=None, results_prefix=''):
    """Applies the previously trained model to testing_instances and returns the results
    @var testing_instances: A Weka Instances object, if testing_keys and meta_data are specified then only those instances will be used
    @var results_prefix: The returned dict will include this prefix - useful if you wanted to do something like: "other_dict.update(results)"
    @return: Returns a dict of instance_key->data_key->value
        See _get_results_for_instance() for what is actually returned
    
    """
    if meta_data is not None and testing_keys is not None:
        testing_instances = _extract_subset(testing_instances, meta_data, testing_keys)
    classAttribute = testing_instances.classAttribute()
    results = defaultdict(dict)
    for i in range(testing_instances.numInstances()):
        key = testing_keys[i] if testing_keys else i
        instance = testing_instances.instance(i)
        results[key] = _get_results_for_instance(instance, model, classAttribute, results_prefix)
    return results

def apply_model_once(model, test_example, prototype_instances, results_prefix=''):
    """@var test_example: a dict with the same features as prototype_instances which should be of the form used to build the model
    feature_key->value
    
    """
    classAttribute = prototype_instances.classAttribute()
    attrs = list()
    for key, value in test_example.items():
        attr = prototype_instances.attribute(str(key))
        if attr is not None:
            if attr.isNominal() or attr.isString():
                value = attr.indexOfValue(value)
            elif attr.isDate():
                value = attr.parseDate(value)
            attrs.append((float(value),attr.index()))
    attrs = sorted(attrs,key=lambda x:x[1])
    attr_values, indices = zip(*attrs)
    instance = get_weka().core.SparseInstance(1.0, attr_values, indices, len(attr_values))
    instance.setDataset(prototype_instances)
    if classAttribute.name() not in test_example:
        instance.setMissing(classAttribute.index())
    results = _get_results_for_instance(instance, model, classAttribute, results_prefix)
    return results

def cross_validate(arff_folder, arffs, classifier_name, classifier_options=None, attribute_selection=None, attribute_selection_options=None, classification_feature=None, n=10, random_seed=None, results_prefix='', print_progress=False):
    """Runs n-fold cross validation exactly once
    @var n: The number of folds
    @var random_seed: The random seed to use for setting up the folds, leave unspecified to use (and alter) the existing random state
    
    """
    with utils.random_guard(random_seed):
        results = defaultdict(dict)
        instances, meta_data = load_inputs(arff_folder, arffs, classification_feature)
        fold_data = dict([(key, instances.get(entry['arff_index']).classValue()) for key, entry in meta_data.items()])
        folds = utils.build_folds(fold_data, n)
        for fold_number in range(n):
            if print_progress: print fold_number
            testing_keys, training_keys = _partition_fold(folds, fold_number)
            classifier_random_seed = random.randint(0, sys.maxint) #if appropriate. as of this writing, on my machine python's maxint is the same as java's maxlong
            model = build_model(instances, classifier_name, meta_data=meta_data, training_keys=training_keys, random_seed=classifier_random_seed)
            temp_results = apply_model(model, instances, meta_data, testing_keys, results_prefix=results_prefix)
            for key, result_data in temp_results.items():
                assert (key not in results)
                result_data[results_prefix+'fold number']=fold_number
                results[key]=result_data
        return results

def to_str(model):
    """Returns the string version of the model, e.g. the JRip rules"""
    return model.toString()



def _load_arffs(arff_folder, arffs, classification_feature=None):
    """Unfortunately there are reasons to return "instances" instead of something superficially more useful"""
    instances, possible_instance_keys = _load_arff_instances(arff_folder, arffs)
    _set_classification_feature(instances, classification_feature)
    return instances, possible_instance_keys
def _load_meta_data(arff_folder):
    return csv_wrapper.read_csv(arff_folder+'instances.csv', key='key')
def _load_arff_instances(arffs_folder, arffs):
    instances = None
    instance_keys = None
    for arff_file in arffs:
        if not arff_file.endswith('.arff'):  arff_file+='.arff'
        #Probe for keys:
        if instance_keys is None:
            actual_arff_file = open(arffs_folder+arff_file)
            first_line = actual_arff_file.readline().strip()
            actual_arff_file.close()
            if first_line.startswith('%Instance_ids: '):
                import json
                instance_keys = json.loads(first_line[len('#Instance_ids: '):])
        
        temp_instances = get_weka().core.Instances(jpype_interface.jpype.java.io.FileReader(arffs_folder+arff_file))
        if instances == None:
            instances = temp_instances
        else:
            instances = get_weka().core.Instances.mergeInstances(instances, temp_instances)
    return instances, instance_keys
def _set_classification_feature(instances, classification_feature=None):
    if classification_feature is None:
        classification_feature = instances.attribute(instances.numAttributes()-1).name()
    instances.setClass(instances.attribute(classification_feature))
def _extract_subset(instances, meta_data, keys):
#TODO: Figure out how to make the following work instead of the ugly delete & sort hack which is implemented currently
#    subset = weka_interface.weka.core.Instances(instances, len(keys))
#    for key in keys:
#        arff_index = meta_data[key]['arff_index']
#        instance = instances.get(arff_index)
#        subset.add(instance)
#    return subset
    subset = get_weka().core.Instances(instances)
    keep = [meta_data[key]['arff_index'] for key in keys]
    keep_set = set(keep)
    for i in reversed(range(len(meta_data))):
        if i not in keep_set:
            subset.delete(i)
    #if not sorted, sort properly, feel free to make efficient
    sorted_keep = sorted(keep)
    for i in range(len(keep)):
        if sorted_keep[i] != keep[i]:
            j = sorted_keep.index(keep[i])
            subset.swap(i,j)
            temp = sorted_keep[i]
            sorted_keep[i] = sorted_keep[j]
            sorted_keep[j] = temp
    return subset
def _java_to_python_results(answer_dist, classAttribute):
    results = dict()
    answer_index = 0
    for score in answer_dist:
        answer_label = classAttribute.value(answer_index)
        results[answer_label]=score
        answer_index+=1
    return results
def _partition_fold(folds, fold_number):
    testing_keys = list()
    training_keys = list()
    for key in folds.keys():
        if folds[key]==fold_number:
            testing_keys.append(key)
        else:
            training_keys.append(key)
    random.shuffle(testing_keys) #in case a classifier depends on the order
    random.shuffle(training_keys)
    return testing_keys, training_keys
def _get_results_for_instance(instance, model, classAttribute, results_prefix=''):
    results = dict()
    if instance.classIsMissing():
        true_label=None
    else:
        true_label = classAttribute.value(int(instance.classValue()))
    answer_dist = model.distributionForInstance(instance)
    answer_dist = _java_to_python_results(answer_dist, classAttribute)
    sorted_answer_dist = sorted(answer_dist.items(), key=lambda (label, score):-score)
    best_label, best_score = sorted_answer_dist[0]
    if len(sorted_answer_dist)>1:
        second_best_score = sorted_answer_dist[1][1]
        margin = best_score - second_best_score
    else:
        margin = None
        if best_label == '':
            best_label=best_score #TODO: Handle numerics properly
    results[results_prefix+'distribution'] = sorted_answer_dist
    results[results_prefix+'margin'] = margin
    results['true label'] = true_label
    results[results_prefix+'assigned label'] = best_label
    results[results_prefix+'right?'] = (best_label==true_label) if true_label is not None else None

    return results



def _add_weka_jar():
    weka_jar_filename = None
    if 'WEKA_HOME' in os.environ:
        weka_jar_filename = os.environ["WEKA_HOME"]
    else:
        try:
            import utilities_external_index
            weka_jar_filename = utilities_external_index.weka_dir+'weka.jar'
        except:
            if os.path.exists('/usr/share/java/weka.jar'): #TODO: Windows/Mac?
                weka_jar_filename = '/usr/share/java/weka.jar'
            #else:???

    jpype_interface.jar_files.append(weka_jar_filename)
_add_weka_jar()



if( __name__ == '__main__'):
    arff_folder = '/data/school/persuasion/results/agreement/baseline/arffs/'
    arffs = ['response_unigram','agreement']
    classification_feature = 'agreement'
    classifier_name = 'weka.classifiers.bayes.NaiveBayes'
    model_filename = '/data/school/temp/NB.model'
    
    instances, meta_data = load_inputs(arff_folder, arffs, classification_feature)
    
    training_keys = meta_data.keys()[:int(0.1*len(meta_data))]
    testing_keys = meta_data.keys()[int(0.1*len(meta_data)):]
    
    model = build_model(instances, classifier_name, meta_data=meta_data, training_keys=training_keys)
    results = apply_model(model, instances, meta_data, testing_keys)
    
    store_model(model, model_filename)
    model = load_model(model_filename)
    
    results = apply_model(model, instances, meta_data, testing_keys)
    
    model = build_model(instances, classifier_name, meta_data=meta_data)
    print to_str(model)
    test_example = {'response_unigram:you':0.5, 'response_unigram:?':0.5, 'agreement':'agree'}
    print apply_model_once(model, test_example, instances)
    
    with utils.random_guard(95064):
        for run in range(5):
            results = cross_validate(arff_folder, arffs, classifier_name, classification_feature=classification_feature)
            right = sum([1 for entry in results.values() if entry['right?']])
            agree = sum([1 for entry in results.values() if entry['assigned label']=='agree'])
            print right, len(results), right/(float(len(results))), agree



