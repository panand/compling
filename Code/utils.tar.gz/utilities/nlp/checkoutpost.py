from post import Post

import pdb

def getIndex(occs, func, vals=None):
  n = 145
  for i,v in enumerate(occs):
    if func(v, vals):
       return i
  return None

dir = "jsons/"
post = Post.from_json(dir+"1110.json")
print post.tree.to_string()
#post.tree.to_graphviz('foo') # creates "foo.dot", "foo.png"
occs = post.occurrences
print getIndex(occs, lambda x,y: x.start>=y, 145)
post.build_features(None, 13, 56)


pdb.set_trace()
