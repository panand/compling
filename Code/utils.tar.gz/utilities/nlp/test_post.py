#!/usr/bin/python

import pdb
import post
f = "testPosts/116.json"

newP = post.Post.from_json(f)



pdb.set_trace()

