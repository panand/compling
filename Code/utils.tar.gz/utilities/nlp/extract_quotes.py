#!/usr/bin/env python
from nlp import stanford_nlp as sn
from nlp import post

def extract_quotes(sentences):
	"""Takes a list of on sentence parses and returns a list of (quote_start, quote_end, how many quotes surround this)."""
	quotes = list()
	quotes_stack = list()
	for sentence in sentences:
		for token in sentence:
			if token['Lemma'] == '``' or token['Lemma'] == '`':
				quotes_stack.append(token[u'CharacterOffsetBegin'])
			elif token['Lemma'] == "''" or token['Lemma'] == "'":
				quotes.append((quotes_stack.pop(), token[u'CharacterOffsetEnd'], str(len(quotes_stack))))
	return quotes

def extract_quotes_from_post(post):
	"""Takes a list of on sentence parses and returns a list of (quote_start, quote_end, how many quotes surround this)."""
	quotes = list()
	quotes_stack = list()
	environments_stack = list()
	for o in post.occurrences:
		if o.lemma == '``' or o.lemma == '`':
			quotes_stack.append(o.start)
			environments_stack.append("quote")
		elif (o.lemma == "''" or o.lemma == "'") and len(quotes_stack)>0:
			quotes.append((quotes_stack.pop(), o.end, environments_stack.pop()))
	return quotes
	
def main():
		sentence = "The boy said 'There aren't any boats' at the docks."
		parses = sn.get_parses(sentence)
		print "Input: %s" % sentence
		print extract_quotes(parses[0])
			
if __name__ == '__main__':
	main()
			
