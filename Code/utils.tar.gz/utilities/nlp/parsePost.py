#! /usr/bin/env python


import sys, os
import stanford_nlp
import codecs
import pdb
import simplejson as json

default_outDir = 'output/'


os.putenv("JAVA_HOME", "/usr/lib/jvm/default-java")
os.putenv("STANFORD_PARSER_HOME", "/var/projects/utilities_external/coreNLP")
sys.path.append('/var/projects/persuasion/code/grab_data')
import discussion as debate
data_root_dir = "/var/projects/persuasion/data"
debate.data_root_dir = data_root_dir
from discussion import Discussion as Debate

sys.path.append('/var/projects/utilities/nlp')
import post

class SetEncoder(json.JSONEncoder):
   def default(self, obj):
       if isinstance(obj, set):
          return list(obj)
       return json.JSONEncoder.default(self,obj)

def parsePost(thread, postname, site, outfilename=None, outDir="output/"):
    debate = Debate("/"+ site, thread)
    posts = debate.posts
    post = posts[int(postname)]
    postText = post.text
    if outfilename == None:
       outfilename = "%s%s_%s.json" % (outDir, thread, postname)
    parsePostFromText(postText, outfilename)

def parsePostFromText(textO, outfilename):
    text = stanford_nlp.utils.ascii_only(textO)
    tokenized_sents, trees, deps = stanford_nlp.get_parses(text)
    stuff = [tokenized_sents, trees, deps] # Superfluous step but I'm not sure if I want it like this or what so WHATEVER YO, I'm just going with the flowing. 
#    print json.dumps(stuff)
    fh = open(outfilename, 'w')
    json.dump(stuff, fh, cls=SetEncoder)
    fh.flush()
    fh.close()

if __name__ == '__main__':
    args = sys.argv[1:]
    if len(args) != 1:
        sys.exit(1)
    toEnterFName = args[0]
    
    filename = args[0]
    f = open(filename, "r")
    for l in f.readlines():
      li = l.rstrip()
      thread, postname, site = li.split()
      parsePost(thread, postname, site)

