#!/bin/bash


python /campusdata/apedelty/utilities/nlp/parse_post.py $SGE_TASK_ID

