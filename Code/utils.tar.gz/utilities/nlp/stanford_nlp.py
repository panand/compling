# -*- coding: utf-8 -*-
"""This uses StanfordCoreNLP to provide parse trees, tokenization, and dependencies 
The primary function is get_parses(text)"""

import os
import sys
import pprint

from misc import utils, jpype_interface

_nlp_pkg = None #Don't use this directly! Use get_nlp_pkg()
_pipeline = None
_gsf = None
def get_nlp_pkg(mem=None):
    """@note: Mostly for internal use, but available if desired"""
    global _nlp_pkg, _pipeline, _gsf
    if _nlp_pkg is None:
        jpype_interface.setup(mem=mem)
        _nlp_pkg = jpype_interface.jpype.JPackage("edu.stanford.nlp")

        props = jpype_interface.jpype.java.util.Properties()
        props.put("annotators", "tokenize, ssplit, pos, lemma, parse")
        props.put("parser.maxlen", "115")
        
        _pipeline = _nlp_pkg.pipeline.StanfordCoreNLP(props)
        tlp = _nlp_pkg.trees.PennTreebankLanguagePack()
        _gsf = tlp.grammaticalStructureFactory()
    return _nlp_pkg



def get_parses(text, preprocess=True):
    """@note: This converts '>', '<' to '}', '{' to make the parser happy
    Note that the character offset may not be correct for unicode strings 
     encoded as non-unicode strings! (should be somewhat expected)
    @warning: The returned structures are partially linked together so do a deep copy if you don't want side effects!
        trees...[x]['token'] -> tokenized_sentences...[x]
        trees...[x]['parent'] -> trees...[y]
    @return: This returns lists on a per sentence basis
        sentences: list of lists (one per sentence) of tokens (dicts)
        trees: dict with {'children':list(), 'parent':whatever, 'token':token_dict(), 'label':POS_etc, etc..}
        dependencies: list of lists (one per sentence) of dependencies (dicts)
    
    """
    get_nlp_pkg("50m") #Ensure setup is performed
      
    text = text.decode('utf-8')
    if preprocess:
        processed_text= __preprocess(text)
    else:
        processed_text = text
    
    tokenized_sentences = list()
    trees = list()
    dependencies = list()
    
    java_sentences = _sentenceTokenize(processed_text)
    
    for java_sentence in java_sentences:
        java_gs, java_deps, java_tokens = _annotateSentence(java_sentence)
        sentence_tokens = [_java_to_python_token(java_token) for java_token in java_tokens]

        tokenized_sentences.append(sentence_tokens)
        
        sentence_tree = _java_to_python_tree(java_gs.root(), sentence_tokens)
        trees.append(sentence_tree)
        
        sentence_dependencies = _java_to_python_dependencies(java_deps, sentence_tokens)
        dependencies.append(sentence_dependencies)

    return tokenized_sentences, trees, dependencies


def in_order_traversal(tree, so_far=None):
    """@return: A list pointing to each node
    @note: Note that this list is not indexed by "index" but by the order each node is visited
    
    """
    if so_far==None: so_far=list()
    so_far.append(tree)
    for child in tree['children']:
        in_order_traversal(child, so_far)
    return so_far

def get_dependencies(text):
    """kept in this form for legacy reasons..."""
    tokenized_sentences, trees, dependencies = get_parses(text)
    all_deps = list()
    for sent_deps in dependencies:
        all_deps.extend(sent_deps)
    return all_deps 


def _sentenceTokenize(text):
    annot_text = get_nlp_pkg().pipeline.Annotation(text)
    _pipeline.annotate(annot_text)
    sentence_annot_class = jpype_interface.jpype.JClass('edu.stanford.nlp.ling.CoreAnnotations$SentencesAnnotation')
    coreMapSentences = annot_text.get(sentence_annot_class)
    return coreMapSentences

def _annotateSentence(coreMapSentence):
    try:
        tree = coreMapSentence.get(jpype_interface.jpype.JClass('edu.stanford.nlp.trees.TreeCoreAnnotations$TreeAnnotation'))
    except:
        #old style
        tree = coreMapSentence.get(jpype_interface.jpype.JClass('edu.stanford.nlp.ling.CoreAnnotations$TreeAnnotation'))
    gs = _gsf.newGrammaticalStructure(tree)
    tdl = gs.typedDependenciesCCprocessed()
    java_tokens = coreMapSentence.get(jpype_interface.jpype.JClass('edu.stanford.nlp.ling.CoreAnnotations$TokensAnnotation'))
    return gs, tdl, java_tokens

def _java_to_python_token(java_token):
    token = dict()
    for java_class in java_token.keySet():
        #Is there a getName() we can use?
        key = str(java_class)
        key = key.replace("<class 'jpype._jclass.edu.stanford.nlp.ling.CoreAnnotations$","").replace("Annotation'>","")
        value = str(java_token.get(java_class))
        if key=='CharacterOffsetBegin' or key=='CharacterOffsetEnd':
            value = int(value)
        token[key]=value
    if 'Value' in token:
        del token['Value']
    return token
def _java_to_python_dependencies(java_deps, sentence_tokens):
    result_deps = list()
    for java_dep in java_deps:
        result_dep = dict()
        result_dep['relation']=java_dep.reln().getShortName()
        result_dep['long_relation']=java_dep.reln().getLongName()
        for index, title in [(java_dep.gov().index()-1, 'governor'), (java_dep.dep().index()-1, 'dependent')]:
            result_dep[title] = sentence_tokens[index].get('Text')
            result_dep[title+'_pos'] = sentence_tokens[index].get('PartOfSpeech')
            result_dep[title+"_index"] = index+1 
        result_deps.append(result_dep)
    return result_deps
def _java_to_python_tree(java_node, sentence_tokens, ancestor_stack = None):
    if ancestor_stack == None:
        ancestor_stack = list()
    tree = dict()
    tree['children']=list()
    tree['dominates']=set()
    tree['ancestors']=list(ancestor_stack)
    tree['parent']= ancestor_stack[-1] if len(ancestor_stack)>0 else None
    index = int(java_node.index())
    tree['index']= index
    if index <= len(sentence_tokens):
        tree['token']=sentence_tokens[index-1]
    else:
        tree['token']=None
    ancestor_stack.append(index)
    for java_child_node in java_node.children():
        child_node=_java_to_python_tree(java_child_node, sentence_tokens, ancestor_stack)
        tree['children'].append(child_node)
        tree['dominates'].update(child_node['dominates'])
        tree['dominates'].add(child_node['index'])
    ancestor_stack.pop()
    if len(tree['children'])==0:
        tree['label'] = tree['token']['Text']
    else:
        tree['label']=str(java_node.label().value())
    return tree

def __preprocess(text):
    text = text.replace('<','{').replace('>','}') 
    return text



def _add_jar_directory():
    core_nlp_dir = None
    if 'STANFORD_PARSER_HOME' in os.environ:
        core_nlp_dir = os.environ["STANFORD_PARSER_HOME"]
    else:
        sys.stderr.write('Attempting to use the Stanford Parser works best if the STANFORD_PARSER_HOME environment variable points to a directory with StanfordCoreNLP')
    jpype_interface.ext_dirs.append(core_nlp_dir)
_add_jar_directory()


if( __name__ == '__main__'):
    #For testing    
    text= 'What determines whether an administrative employee must be paid for overtime?'
    tokenized_sentences, trees, dependencies = get_parses(text)
    for tree in trees:
        as_list = in_order_traversal(tree)
        for entry in as_list:
            print entry
    
    pprinter = pprint.PrettyPrinter(indent=2)
    pprinter.pprint(get_parses(text))
    for dep_sent in dependencies:
        for dep in dep_sent:
            print dep
