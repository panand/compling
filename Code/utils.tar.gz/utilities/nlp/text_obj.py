from parsing import tokenizer
from itertools_recipes import flatten

class TextObj:
    def __init__(self,text=None):
        self.text = text
        self.sentences = None
        self.tokens = None
        self.pos = None
        
        self.process()
    
    def process(self):
        self.sentences = tokenizer.tokenize(self.text, break_into_sentences=True, leave_whitespace=False)
        self.tokens = list(flatten(self.sentences))
        
