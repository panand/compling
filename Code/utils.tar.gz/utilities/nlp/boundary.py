import pdb
from collections import deque as d

class Boundary:
	def __init__(self, index, type, environment, group='XX'):
		if group == 'XX':
			group = environment
		self.index = index
		self.environment = environment
		self.type = type
		self.group = group
	def __repr__(self):
		return repr((self.index, self.environment, self.type, self.group))

class Boundaries:
	def __init__(self):
		#sorting on index, then type, to ensure that begin is before end
		self.boundaries = []
	def initializeFromTuples(self, tuples):
		boundaries = []
		#pdb.set_trace()
		for i in range(len(tuples)):
			t = tuples[i]
			begin = Boundary(t[0], "begin", t[2], i)
			end = Boundary(t[1], "end", t[2], i)
			boundaries.extend([begin, end])
		self.boundaries = sorted(sorted(boundaries, key=lambda boundary: boundary.type), key = lambda boundary: boundary.index)
		
	def walk(self, start, stop):
		boundaries = self.boundaries
		self.partitions = []
		environmentStack = d([])
		
		if boundaries[0].index > start:
			boundaries = [Boundary(start, "begin", "none", -1)] + boundaries
		if boundaries[-1].index < stop:
			boundaries.append(Boundary(stop, "end", "none", -1))
		
		for i in range(len(boundaries)-1):
			curBoundary = boundaries[i+1]
			prevBoundary = boundaries[i]
			if prevBoundary.type == "begin":
				environmentStack.append(prevBoundary.group)
			elif prevBoundary.type == "end":
				environmentStack.remove(prevBoundary.group)
			
			if curBoundary.index == prevBoundary.index:
				continue
			else:
				self.partitions.append([prevBoundary.index, curBoundary.index, self.stringifyEnvironments(environmentStack, boundaries)])
	
	def stringifyEnvironments(self, environmentStack, boundaries):
		temp = d(environmentStack)
		if(len(temp) == 0):
			return "none"
		else:
			return ' '.join([boundaries[x].environment for x in environmentStack])

	def __repr__(self):
		return repr(self.boundaries)

def main():
	tuples = [(1,10,"A"), (3,6,"B"), (6,14,"C"), (11,18,"D")]
	b = Boundaries()
	b.initializeFromTuples(tuples)
	print b
	b.walk(1, 100)
	print b.partitions

if __name__ == "__main__":
	main()
 