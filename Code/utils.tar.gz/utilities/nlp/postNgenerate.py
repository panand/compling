#!/usr/bin/python

import pdb
import post
from collections import defaultdict
import os

def runIt():
	for root, dirs, files in os.walk('sampledPosts/'):
		bigList = []
		for fname in files:
			bigList += [fname[:-5]]
		pdb.set_trace()
		for fname in files:	
			newP = newP = post.Post.from_json('sampledPosts/'+fname)
			allSents = []
			touched = []
			text = ''

			for x in xrange(len(newP.sentstarts)): 
				allSents.append({'start': newP.sentstarts[x], 'length': (newP.sentends[x] - newP.sentstarts[x])})
				touched.append({'arg': 0, 'sidedness': 0})
				text = str(newP.text)

			datFile = {"cur":-1,"text":text,"indices":allSents,"touched":touched}
			writeF = open('sampledPostsOut/'+fname[:-5]+'.txt', 'w')
			writeF.write(str(datFile))
			writeF.close()

if __name__ == '__main__':
	runIt()
