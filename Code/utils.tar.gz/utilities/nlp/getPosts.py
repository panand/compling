#!/usr/bin/env python
import MySQLdb
import sys
import pdb
import random
from collections import defaultdict
import shutil

dbname = 'annotations_plus'
usernm = 'root'


def getPosts():
	db = MySQLdb.connect(db=dbname, user=usernm)
	dbCur = db.cursor()
	dbCur.execute('''SELECT topic, count, id FROM (SELECT topic, IF(isnull(parent), "N", "Y") AS parented, posts.id, count(*) AS count FROM sentences JOIN posts ON sentences.containingPost=posts.id WHERE topic != "unknown" GROUP BY containingPost) postCounts WHERE count >= 10 AND count <= 20;''')
	rawPosts = dbCur.fetchall()
	dbCur.close()
	postList = defaultdict(list)
	for row in rawPosts:
		postList[row[0]] += [(row[2], row[1])]
	sampledList = defaultdict(list)
	desiredTopics=['existence of god', 'abortion', 'evolution', 'death penalty']
	for topic in desiredTopics:
		sNum = 0
		addedList = []
		while sNum < 500:
			addOne = random.sample(postList[topic], 1)
			if addOne[0] not in addedList:
				sampledList[topic] += [addOne]
			addedList += [addOne[0][0]]
			sNum += int(addOne[0][1])
	
	for topic in sampledList:
		for post in sampledList[topic]:
			shutil.copy2('/home/jking/persuasion/data/convinceme/output/' + str(post[0][0]) + '.json', '/var/projects/utilities/nlp/sampledPosts')
	pdb.set_trace() 

if __name__ == '__main__':
	getPosts()
