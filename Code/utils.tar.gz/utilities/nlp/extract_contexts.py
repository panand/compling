#!/usr/bin/env python

import re, sys
from os.path import basename
import json

from nlp import post

DEBUG = False

interm_words = ' ?([^.!?:; ]+ ){,3}'
def _rx_abs(word): return (word, re.compile(r'\b' + word + r'\b', re.IGNORECASE))
def _rx_stem(word): return (word, re.compile(r'\b' + word, re.IGNORECASE))
def _rx_split(before, after):
    return (before + ' X ' + after,
            re.compile(r'\b' + before + r'\b' + interm_words + r'\b' + after))

# _featlists is a mapping: (major class, minor class) =>
#                            ([ (word, regex) ],   # do search in each occurrence
#                             [ (phrase, regex) ]) # search full post text

_featlists = {

    ('quotation', 'quotation'):
        ([], [ ('"', re.compile(r'"[^"]+"')) ]),

    ('question', 'question'):
        ([], [ ('?', re.compile(r'[^.!?:;"\' ][^.!?:;]+\?')) ] ),

    ('conditional', 'conditional'):
        ([ _rx_abs('if') ], []),

    ('commitment & opposition', 'commitment regardless of subject & negation'):
        (map(_rx_stem,
            [ 'agree', 'accept', 'acknowledg', 'certain', 'demonstrat',
              'discount', 'indicat', 'know', 'show', 'sure' ]),
         []),

    ('commitment & opposition', 'commitment with 1st person, opposition to 2nd'):
        (map(_rx_stem,
            [ 'admit', 'advocat', 'afraid', 'agree', 'argu', 'assum',
              'believ', 'claim', 'choos', 'define', 'expect', 'fear',
              'guess', 'hope', 'support', 'suppos', 'suspect', 'think',
              'say', 'wish', 'worry' ]),
         []),

    ('commitment & opposition', 'opposition to 1st person, commitment with 2nd'):
        (map(_rx_stem,
            [ 'attack', 'deny', 'disagree', 'doubt', 'refuse', 'question' ]),
         []),

    ('commitment & opposition', 'opposition regardless of person'):
        ([ _rx_abs('pretend') ], []),

    ('doubt and certainty', 'commitment'):
        (map(_rx_abs,
            [ 'certainly', 'definitely', 'likely', 'maybe', 'obviously',
              'probably', 'undeniably', 'undoubtedly' ]),
         map(_rx_abs,
            [ 'it appears', 'it seems', 'of course' ]) \
         + map(_rx_abs, [ 'i think', 'i would say' ])),

    ('doubt and certainty', 'doubt'):
        ([ _rx_abs('doubt') ], []),

    ('doubt and certainty', 'ignorance'):
        (map(_rx_abs, [ 'maybe', 'perhaps' ]),
         [ _rx_abs('for all i know') ]),

    ('doubt and certainty', 'guess'):
        ([ _rx_abs('guess') ], []),

    ('actuality', 'commitment'):
        (map(_rx_abs, ['actually', 'really']),
         map(_rx_abs, [ 'as a matter of fact', 'for a fact', 'in actual fact', 'in fact'])),

    ('limitation', 'limitation'):
        (map(_rx_abs, ['generally', 'mainly', 'typically']),
         map(_rx_abs, [ 'in general', 'on the whole' ]) \
         + map(lambda pair: _rx_split(*pair), [ ('in', 'instance'), ('in', 'case') ])),

    ('viewpoint', 'viewpoint'):
        ([],
         map(lambda pair: _rx_split(*pair),
            [ ('from', 'perspective'), ('in', 'opinion'), ('in', 'view'), ('in', 'cases') ])),

    ('imprecision', 'imprecision'):
        (map(_rx_abs, ['approximately', 'like', 'roughly']),
         map(_rx_abs, ['if you can call it that', 'kind of', 'so to speak', 'sort of'])),

    ('evaluation or judgment', 'commitment'):
        (map(_rx_abs,
            [ 'amazingly', 'astonishingly', 'bizarrely', 'commendably', 'conveniently',
              'curiously', 'disappointingly', 'disturbingly', 'fortunately', 'funnily',
              'happily', 'hopefully', 'illogically', 'inevitably', 'interestingly',
              'ironically', 'justifiably', 'justly', 'luckily',  'oddly', 'paradoxically',
              'predictably', 'preferably', 'regretfully', 'regrettably', 'rightly', 'sadly',
              'sensibly', 'significantly', 'strangely', 'surprisingly', 'tragically',
              'unaccountably', 'unbelievably', 'unfortunately', 'wisely' ]),
         map(_rx_abs, [ 'even worse', 'more importantly', 'oddly enough', 'to my surprise', 'unhappily unreasonably' ]) \
         + map(lambda pair: _rx_split(*pair), [ ('as','expect'), ('as','guess') ])),

    ('style', 'commitment'):
        (map(_rx_abs,
            [ 'confidentially', 'figuratively', 'frankly', 'honestly', 'truthfully',
              'literally', 'seriously', 'simply' ]),
         map(_rx_abs,
            [ 'to tell you the truth',  'with all due respect', 'if i may say so',
              "if you don't mind my", 'in a word', 'in brief', 'put bluntly', 'put simply',
              'putting it bluntly', 'simply put', 'strictly speaking', 'technically speaking',
              'to be blunt', 'to put it bluntly' ])),

    ('modal', 'commitment'):
        (map(_rx_abs,
            [ 'arguably', 'assuredly', 'certainly', 'clearly', 'conceivably', 'definitely',
              'doubtless', 'evidently',  'improbably', 'incontestably', 'incontrovertibly',
              'presumably', 'probably', 'surely', 'undoubtedly' ]),
         map(_rx_abs, [ 'for certain', 'no doubt' ])),

    ('modal', 'ignorance'):
        (map(_rx_abs, [ 'maybe', 'perhaps', 'possibly' ]), []),

    ('evidential', 'evidential'):
        (map(_rx_abs,
            [ 'according', 'allegedly', 'apparently', 'evidently', 'manifestly',
              'obviously', 'ostensibly', 'patently', 'purportedly', 'reportedly',
              'reputedly', 'seemingly', 'supposedly', 'visibly' ]),
         [])

}
        
def extract_contexts(post_id, post, features=[]):
    if len(features) == 0: features = _featlists.keys()
    else: features = filter(lambda x: x in _featlists, features)

    spans = [] # span := [ span-id, [ start, stop, { "category": (major, minor), "environment_indicators": [ (word, occurrence_id) ] } ] ]

    for featpair in features:
        (word_pairs, phrase_pairs) = _featlists[featpair]
        for word, rx in word_pairs:
            for occ_i, occ in enumerate(post.occurrences):
                if rx.match(occ.text):
                    spans.append( [ "%s-%s" % (str(post_id), len(spans)+1),
                                    [ occ.start,
                                      occ.end,
                                      { "category": featpair,
                                        "environment_indicators":
                                            [ (word, str(occ_i)) ] } ] ] )
        for phrase, rx in phrase_pairs:
            for m in rx.finditer(post.text):
                spans.append( [ "%s-%s" % (str(post_id), len(spans)+1),
                                [ m.start(),
                                  m.end(),
                                  { "category": featpair,
                                    "environment_indicators":
                                        [ (m.group(0), -1) ] } ] ] )

    f_spans = open('%s.spans.json' % str(post_id), 'w')
    json.dump(spans, f_spans)
    f_spans.close()

