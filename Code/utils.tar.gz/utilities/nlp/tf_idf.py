from collections import Counter
import math

class IdfCalc:
    """this is used for generating idf
    it keeps a running total of term-document counts
    
    """
    def __init__(self):
        self.document_count = 0
        self.frequency = Counter()
    
    def add_doc(self, tokens):
        self.frequency.update(set(tokens))
        self.document_count += 1
    
    def update(self, other):
        """combines with another IdfCalc object (useful for parallelizing"""
        self.frequency.update(other.frequency)
        self.document_count += other.document_count
    
    def get_idf(self):
        """@note: you probably want to store this dict for later use (pickle it or something)"""
        idf = dict()
        for token, count in self.frequency.items():
            idf[token]=math.log10(self.number_of_documents/float(count)) #TODO: make more efficient ... if it matters
        return idf
            

