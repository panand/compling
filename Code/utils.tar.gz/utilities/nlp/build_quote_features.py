#!/usr/bin/env python
import os, sys, json
from nlp import post
from nlp import extract_quotes
from nlp import boundary
import pdb
DEFAULT = "/var/projects/persuasion/data/convinceme/output_by_thread/1/"
OUT_DIR = "/var/projects/persuasion/data/convinceme/environments/"


def get_post_from_thread(directory):
	posts = {}
	for f in os.listdir(directory):
		f_name = os.path.join(directory, f)
		(name, ext) = os.path.splitext(f)
		if os.path.isfile(f_name) and ext == '.json':
			#print "Creating post from - %s" % f_name
			posts[name] = post.Post.from_json(f_name)
		elif os.path.isdir(f_name):
			temp_dict = get_post_from_thread(f_name)
			for key in temp_dict:
				posts[key] = temp_dict[key]
	return posts
	
def main():
	feats = ['unigram', 'initialism', 'lengths', 'punctuation', 'liwc', 'dep']
	post_list = []
	if len(sys.argv) > 1:
		post_dict = get_post_from_thread(sys.argv[1])
	else:
		post_dict= get_post_from_thread(DEFAULT)
	
	#Segment and find features in quoted and unquoted spans of text
	for key in post_dict:
		post = post_dict[key]
		quote_list = extract_quotes.extract_quotes_from_post(post)
		out = []
		#print "Post: %s\n" % post.text
		f = open(os.path.join(OUT_DIR, key+'.json'), "w")
		if len(quote_list) > 0:
			b = boundary.Boundaries()
			#print post.text
			pdb.set_trace()
			b.initializeFromTuples(quote_list)
			b.walk(post.sentstarts[0], post.sentends[len(post.sentends) - 1])
			#print "Partitions: %s\n" % b.partitions
			i = 0;
			for partition in b.partitions:
				#extract features if this partition is not a quote embedded in a quote.
				if len(partition[2].split()) < 3:
					post.build_features(None, partition[0], partition[1])
					out.append(post.to_feat_json(boundary=partition))
					i= i + 1
			json.dump(out, f)
		else:
			post.build_features()
			json.dump([post.to_feat_json()], f)
		f.close()


if __name__ == '__main__':
	main()
