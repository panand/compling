""" 
so:
----
text = 'hi michael'
other_text = 'blah'
filename = ....

import word_category_counter

word_category_counter.set_default_dictionary(filename)

#one off:
scores_dict = word_category_counter.score_text(text)

#keep a running total:
foo = word_category_counter.WordCatCounter()
foo.score_text(text)
foo.score_text(other_text)
for category, count in foo.scores.items():
    print category, count/float(foo.scores['Word Count'])

----
should work
"""


import re
import codecs
from collections import Counter
from misc import utils

from parsing import tokenizer as parser

class Dictionary():
    """categories is a dict of identifier (number) -> category name
    dictionary is a dict of word->category identifier
    conditional_dictonary is like dictionary, but for special cases: e.g. "kind" depends on "of" and "like" depends on what precedes it
    regexs is a list of (regular expression, categories),
       if a word is not in the dictionary, it gets checked against the regular expressions
         the first one it matches adds the word and categories to the dictionary
    
    """
    
    def __init__(self, filename=None):
        self.categories = dict()
        self.regexs = list()
        self.dictionary = dict()
        self.conditional_dictonary = dict()
        
        self.use_dict(filename)
    
    def score_text(self, text, scores=None):
        """@param scores: scores should be a counter, if not one will be created"""
        if scores == None: scores = Counter()
        sentences = parser.tokenize(text.lower(),break_into_sentences=True)
        for sentence in sentences:
            scores['Sentences'] += 1
            for punct in ['?','!']:
                if len(sentence) > 0 and sentence[-1].endswith(punct):
                    scores['Sentences ending with "'+punct+'"'] += 1
                    break
            for i in range(len(sentence)):
                token = sentence[i]
                
                scores['Word Count'] += 1
                if len(token) >= 6: scores['Words longer than 6 letters'] += 1
                if '"' in token: scores['Quotation Marks'] += 1
                
                #convoluted special cases...
                if token in self.conditional_dictonary:
                    for use_previous, conditional, category_if_met, category_if_not_met in self.conditional_dictonary[token]:
                        if use_previous and i-1>=0:
                            previous_token = sentence[i-1]
                            found = False
                            for category_id in self.dictionary[previous_token]:
                                if category_id in conditional:
                                    if category_if_met !=None:
                                        category = self.categories[category_if_met]
                                        scores[category]+=1
                                        found=True
                                        break
                            if not found:
                                if category_if_not_met != None:
                                    category = self.categories[category_if_not_met]
                                    scores[category]+=1
                        elif not use_previous and i+1<len(sentence):
                            next_token = sentence[i+1]
                            if next_token == conditional:
                                if category_if_met != None:
                                    category = self.categories[category_if_met]
                                    scores[category]+=1
                            else:
                                if category_if_not_met !=None:
                                    category = self.categories[category_if_not_met]
                                    scores[category]+=1
                                    
                self.score_word(token, scores)
        return scores
    
    def score_word(self, word, scores=None):
        if scores == None: scores = Counter()
        word=word.lower()
                            
        if word in self.dictionary:
            for category_id in self.dictionary[word]:
                category = self.categories[category_id]
                scores[category]+=1
        else:
            for (regex, categories) in self.regexs:
                if regex.match(word):
                    self.dictionary[word] = categories
                    break
            if word not in self.dictionary:
                self.dictionary[word] = list()

            for category_id in self.dictionary[word]:
                category = self.categories[category_id]
                scores[category]+=1
        return scores
    
    def use_dict(self, dictionary_file, LIWC_Style=True, use_LIWC_categories=True):
        if dictionary_file is None: return
        if use_LIWC_categories:
            self.add_LIWC_categories()
        
        category_mode = False
        for line in codecs.open(dictionary_file,'r','utf-8'):
            if line.startswith('#'): continue
            line = line.strip()
            if line == '': continue
            
            if line == '%':
                category_mode = not category_mode
                continue
            if category_mode:
                self.add_category(line)
                continue
            
            word, categories, special_cases = self.read_dict_line(line, LIWC_Style)
            if type(word)==type(re.compile('.')): #TODO fix
                self.regexs.append((word,categories))
            else:
                self.dictionary[word] = categories
                if special_cases:
                    self.conditional_dictonary[word]=special_cases
                

    def add_category(self, line):
        line_tokens = line.split()
        identifier = line_tokens.pop(0)
        category = ' '.join(line_tokens)
        identifier = utils.maybe_convert(identifier)
        self.categories[identifier] = category
    
    following_re = re.compile('<(\S+)>(\d+)(/(\d+))?')
    preceding_re = re.compile('\((\d+(\s\d+)*)\)(\d+)(/(\d+))?')
    def read_dict_line(self, line, LIWC_Style=True):
        if line.startswith('"'): #
            close_quote = line.rfind('"')
            word = line[1:close_quote]
            remainder =  line[close_quote+1:]
        else:
            line_tokens = line.split()
            word = line_tokens.pop(0)
            remainder = line.strip(word).strip()

        if word.startswith('^'):
            word = re.compile(word)
        elif LIWC_Style and '*' in word:
            word = word.replace('*','.*')
            word = re.compile(word)
            
        special_cases=list()
        if '(' in remainder:
            for previous_categories, junk, if_met, junk2, if_not_met in Dictionary.preceding_re.findall(remainder):
                if if_not_met == '': if_not_met = None
                special_cases.append((True, utils.maybe_convert(previous_categories.split()), utils.maybe_convert(if_met), utils.maybe_convert(if_not_met)))
                remainder = Dictionary.preceding_re.sub('', remainder)
        if '<' in remainder:
            for following_word, if_met, junk, if_not_met in Dictionary.following_re.findall(remainder):
                if if_not_met == '': if_not_met = None
                special_cases.append((False, following_word, utils.maybe_convert(if_met), utils.maybe_convert(if_not_met)))
                remainder = Dictionary.following_re.sub('', remainder)
        if len(special_cases)==0: special_cases = None

        categories = utils.maybe_convert(remainder.strip().split())
        return word, categories, special_cases
    
    def add_LIWC_categories(self):
        liwc_categories = ["Total pronouns", "1st person singular", "1st person plural", "Total first person", "Total second person", "Total third person", "Negations", "Assents", "Articles", "Prepositions", "Numbers", "Affective or Emotional Processes", "Positive Emotions", "Positive feelings", "Optimism and energy", "Negative Emotions", "Anxiety or fear", "Anger", "Sadness or depression", "Cognitive Processes", "Causation", "Insight", "Discrepancy", "Inhibition", "Tentative", "Certainty", "Sensory and Perceptual Processes", "Seeing", "Hearing", "Feeling", "Social Processes", "Communication", "Other references to people", "Friends", "Family", "Humans", "Time", "Past tense verb", "Present tense verb", "Future tense verb", "Space", "Up", "Down", "Inclusive", "Exclusive", "Motion", "Occupation", "School", "Job or work", "Achievement", "Leisure activity", "Home", "Sports", "Television and movies", "Music", "Money and financial issues", "Metaphysical issues", "Religion", "Death and dying", "Physical states and functions", "Body states, symptoms", "Sex and sexuality", "Eating, drinking, dieting", "Sleeping, dreaming", "Grooming", "Swear words", "Nonfluencies", "Fillers","Similes"]
        cat_id = 1
        for category in liwc_categories:
            self.categories[cat_id] = category
            cat_id += 1

class WordCatCounter():
    """just like score text, but keeps a running total
    scores is a counter (dict) with category -> wordcount
    total_words is the total number of words seen
    
    """
    default_dictionary_obj = None
    def __init__(self, dictionary_obj=None):
        if dictionary_obj is None: dictionary_obj = WordCatCounter.default_dictionary_obj
        self.dictionary_obj = dictionary_obj
        self.reset_scores()
    def score_text(self, text):
        self.scores = self.dictionary_obj.score_text(text, self.scores)
        return self.scores
    def score_word(self, word):
        self.scores = self.dictionary_obj.score_word(word, self.scores)
        return self.scores
    def score_file(self, filename):
        for line in codecs.open(filename, 'r', 'utf-8'):
            self.score_text(line)
        return self.scores
    def reset_scores(self):
        self.scores = Counter()
        
def set_default_dictionary(filename):
    WordCatCounter.default_dictionary_obj = Dictionary(filename)
def score_text(text):
    word_cat_counter = WordCatCounter()
    return word_cat_counter.score_text(text)
def score_word(word):
    word_cat_counter = WordCatCounter()
    return word_cat_counter.score_word(word)
def score_file(filename):
    word_cat_counter = WordCatCounter()
    return word_cat_counter.score_file(filename)

def get_category_number(category):
    """@summary: Useful for "grep"ing the dic file to lookup words"""
    word_cat_counter = WordCatCounter()
    for number, name in word_cat_counter.dictionary_obj.categories.items():
        if name == category:
            return number

def normalize(scores):
    """@summary: Converts counts to percentages"""
    new_scores = Counter()
    for category, score in scores.items():
        if category != 'Word Count' and category != 'Sentences':
            if category.startswith('Sentences '):
                score = 100.0*score/float(scores['Sentences'])
            else:
                score = 100.0*score/float(scores['Word Count'])
        new_scores[category]=score
    return new_scores

try:    
    import os
    set_default_dictionary(os.path.abspath(os.path.join(os.path.dirname(__file__), 'data'))+'/DefaultDic2003.dic')
except:
    print 'failed to load word category counter dictionary'
