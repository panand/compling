#! /usr/bin/env python


import sys, os
sys.path.append('/campusdata/apedelty/utilities/nlp/')
import simplejson as json
import stanford_nlp
import codecs


inDirPrefix='/campusdata/apedelty/utilities/textonly/'
outDir = '/campusdata/apedelty/output/'


def main():
    args = sys.argv[1:]
    if len(args) != 1:
        sys.exit(1)
    filename = args[0]
    filelist = os.listdir(inDirPrefix)
    fh = codecs.open(inDirPrefix + filename, 'rU', 'utf-8')
    if not filename in filelist:
        raise IndexError
        sys.exit(1) 

    text = stanford_nlp.utils.ascii_only(fh.read())
    fh.close()
    tokenized_sents, trees, deps = stanford_nlp.get_parses(text)
    stuff = [tokenized_sents, trees, deps] # Superfluous step but I'm not sure if I want it like this or what so WHATEVER YO, I'm just going with the flowing. 
    del fh; fh = open(outDir+filename+'.json', 'w')
    json.dump(stuff, fh)
    fh.flush()
    fh.close()












if __name__ == '__main__':
    main()

