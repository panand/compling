import pdb

debugF = "debug_out"

def init(debugfile):
        debugF = open(debugfile, "w")

def debug(str):
        return;
        debugF.write(str)
        debugF.flush()

