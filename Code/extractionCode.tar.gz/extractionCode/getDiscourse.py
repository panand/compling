#!/usr/bin/python

import pdb
import pprint
from collections import defaultdict
from collections import Counter
from operator import itemgetter
import re
import sys
import os
import csv
import json
from debug import debug, init

import discussion as debate
data_root_dir = "/var/projects/persuasion/data"
debate.data_root_dir = data_root_dir
from discussion import Discussion as Debate

sys.path.append('/var/projects/utilities/nlp')
import post

init("debug_out")


def explore(directory, ids, site, func, pd = False):
    ret = []
    for threadId in ids:
        filename = threadId
        debug("Processing %s\n" % filename)
        debate = Debate("/"+ directory, filename, loadPostData = pd)
        for argument in debate.get_posts():
            try:
               ret.append(func(argument, debate))
            except:
                debug("Cannot process post %s\n" % threadId)
                continue
    return ret

def exp(argument, deb):
            id = argument.id
            try:
                text = argument.text
            except:
                text = ""
            try:
                author = argument.author
            except:
                author = "!!UNKNOWN"
            if author == None:
                author = "!!UNKNOWN"
            if argument.parent_id:
               if type(argument.parent_id) in [unicode] :
                  parent_text = ""
               else:
                  parent_text = deb.posts[argument.parent_id].text
            else:
               parent_text = ""
		
            try:
                timestamp = argument.timestamp
            except:
                timestamp = 0

            try:
                tokens = argument.tokens
                starts = [x.start for x in tokens]
                startDict = dict(zip(starts, range(len(starts))))
                demons = [startDict[x.start] for x in filter(lambda x: x.lemma in ["this", "that"] and x.pos == "DT", tokens)]
                if demons != []:
                  moded  = []
                  real = []
                  for rel in argument.pst.dependencies:
                      if rel.dep_index in demons or rel.gov_index in demons:
                         if  rel.relation == "det":
                           moded.append(rel.dep_index) 
                         else:
                           real.append(rel)
                  if real != []:
                     print "%s\n%s\n%s" % (parent_text, "-"*40, argument.text)
            except:
                tokens = None

def examineAllPosts(directory = '../../data/parsed_debates/', ids=[-1], site='fourforums', func=exp, postData = False):
    global debate
    if ids[0] == -1:
        realIds = [int(os.path.splitext(file)[0]) for file in os.listdir(os.path.join(debate.data_root_dir, directory, "discussions"))]
    else:
        realIds = ids
    return explore(directory, realIds, site, func, postData)




if __name__ == '__main__':

     postList = examineAllPosts(directory = 'fourforums', site='fourforums', ids=[107], postData=True)

